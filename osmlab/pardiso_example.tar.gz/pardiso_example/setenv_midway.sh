module load gcc/4.8
module load mkl/11.2
